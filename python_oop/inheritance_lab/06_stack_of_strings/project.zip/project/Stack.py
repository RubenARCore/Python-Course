class Stack:
    def __init__(self):
        self.data: list = []

    def push(self, element: str):
        self.data.append(element)

    def pop(self):
         return self.data.pop()

    def top(self):
        return self.data[-1]

    def is_empty(self):
        if self.data:
            return True
        else:
            return False

    def __str__(self) -> str:
        self.data.reverse()
        return "\n".join(self.data)